# Growora Web

Web landing responsive creada para Growora.

## Archivos
- index.html
- style.css

## Uso
Abre `index.html` en tu navegador para verla.

Nota: el formulario de contacto es visual. Para recibir mensajes reales hay que conectarlo a un servicio de formularios o backend.
